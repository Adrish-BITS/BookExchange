package com.fsd.asg1.BookExchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
